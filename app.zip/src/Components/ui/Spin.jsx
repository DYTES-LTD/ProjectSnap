import React from 'react'
import './spin.css'

function Spin() {
  return (
  
    <div class="loader"></div>


  )
}

export default Spin

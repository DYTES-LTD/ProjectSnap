  import React from 'react'
  import Userhome from '../Components/Userhome';
  import '../Components/CssFiles/userhome.css'
 


  function Homepage() {
    
  

  
    return (
      <div className='home min-h-screen flex items-center justify-center mb-4'>
        <Userhome /> 
      </div>
    )
  }

  export default Homepage
